import os

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Load variables from a .env file if one exists (optional for Day 1).
load_dotenv(os.path.join(BASE_DIR, ".env"))


class Config:
    # Used by Flask to sign sessions and flash messages (needed from Day 2).
    # Always set a real value through the environment in production.
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-only-change-me")

    # SQLite file lives in the instance/ folder, which Flask creates for us.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "sqlite:///" + os.path.join(BASE_DIR, "instance", "coursehub.db"),
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
