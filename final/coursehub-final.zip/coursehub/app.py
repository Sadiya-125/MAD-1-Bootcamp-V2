import os
import re
from functools import wraps
from urllib.parse import urlsplit

import click
from flask import (
    Flask,
    abort,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from flask_wtf.csrf import CSRFProtect

from config import Config
from models import (
    CATEGORIES,
    LEVELS,
    ROLES,
    Course,
    Enrollment,
    Lesson,
    LessonCompletion,
    User,
    db,
    utc_now,
)

# Checks a hidden token on every POST form, so other sites can't submit
# forms on a user's behalf (CSRF). Every <form method="post"> needs:
# <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
csrf = CSRFProtect()

# Roles a visitor may pick on the register form. Admins are created
# with the `flask create-admin` command, never through the website.
SIGNUP_ROLES = ("student", "instructor")

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MIN_PASSWORD_LENGTH = 8


# ---------------------------------------------------------------------------
# Access decorators
# ---------------------------------------------------------------------------

def login_required(view):
    """Send anonymous visitors to the login page, then back here afterwards."""

    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login", next=request.full_path))
        return view(*args, **kwargs)

    return wrapped


def role_required(*roles):
    """Allow only logged-in users whose role is in `roles`. Others get 403."""

    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if g.user.role not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


student_required = role_required("student")
instructor_required = role_required("instructor")
admin_required = role_required("admin")


def slugify(text):
    """'Intro to Flask!' -> 'intro-to-flask'"""
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def get_enrollment(student_id, course_id):
    """The Enrollment row for this student and course, or None."""
    return db.session.scalar(
        db.select(Enrollment).where(
            Enrollment.student_id == student_id, Enrollment.course_id == course_id
        )
    )


def unique_slug(title):
    """Make a slug from the title, adding -2, -3... if it's already used."""
    base = slugify(title) or "course"
    slug, n = base, 2
    while db.session.scalar(db.select(Course.id).where(Course.slug == slug)):
        slug, n = f"{base}-{n}", n + 1
    return slug


def is_web_url(value):
    return value.startswith(("http://", "https://"))


def read_course_form(form):
    """Clean the course builder form. Returns (values, errors)."""
    values = {
        "title": form.get("title", "").strip(),
        "short_description": form.get("short_description", "").strip(),
        "description": form.get("description", "").strip(),
        "category": form.get("category", ""),
        "level": form.get("level", ""),
        "price": form.get("price", "0").strip() or "0",
        "thumbnail": form.get("thumbnail", "").strip(),
    }
    errors = []
    if not values["title"]:
        errors.append("Title is required.")
    elif len(values["title"]) > 200:
        errors.append("Title must be 200 characters or fewer.")
    if len(values["short_description"]) > 500:
        errors.append("Short description must be 500 characters or fewer.")
    if values["category"] not in CATEGORIES:
        errors.append("Pick a category.")
    if values["level"] not in LEVELS:
        errors.append("Pick a level.")
    try:
        values["price"] = float(values["price"])
        if values["price"] < 0:
            raise ValueError
    except ValueError:
        errors.append("Price must be a number, 0 or more.")
    if values["thumbnail"] and not is_web_url(values["thumbnail"]):
        errors.append("Thumbnail must be a link starting with http:// or https://.")
    return values, errors


def read_lesson_form(form):
    """Clean the lesson form. Returns (values, errors)."""
    values = {
        "title": form.get("title", "").strip(),
        "content": form.get("content", "").strip(),
        "video_url": form.get("video_url", "").strip(),
        "duration": form.get("duration", "").strip(),
        "order": form.get("order", "").strip(),
        "is_free_preview": form.get("is_free_preview") == "on",
    }
    errors = []
    if not values["title"]:
        errors.append("Lesson title is required.")
    elif len(values["title"]) > 200:
        errors.append("Lesson title must be 200 characters or fewer.")
    if values["video_url"] and not is_web_url(values["video_url"]):
        errors.append("Video link must start with http:// or https://.")
    for field, label in (("duration", "Duration"), ("order", "Position")):
        if values[field] == "":
            values[field] = None
            continue
        try:
            values[field] = int(values[field])
            if values[field] < 0:
                raise ValueError
        except ValueError:
            errors.append(f"{label} must be a whole number, 0 or more.")
    return values, errors


def is_safe_next(target):
    """Only follow `next` if it points back into this site (no open redirect)."""
    if not target:
        return False
    parts = urlsplit(target)
    return not parts.scheme and not parts.netloc and target.startswith("/")


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)
    os.makedirs(app.instance_path, exist_ok=True)

    db.init_app(app)
    csrf.init_app(app)
    with app.app_context():
        db.create_all()

    # --- Load the logged-in user once per request ---------------------------

    @app.before_request
    def load_current_user():
        g.user = None
        user_id = session.get("user_id")
        if user_id is not None:
            user = db.session.get(User, user_id)
            # A deactivated or deleted account is logged out immediately.
            if user is None or not user.is_active:
                session.clear()
            else:
                g.user = user

    @app.context_processor
    def inject_user():
        return {"current_user": g.get("user")}

    # --- Public pages -------------------------------------------------------

    @app.route("/")
    def home():
        return redirect(url_for("course_list"))

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if g.user:
            return redirect(url_for("dashboard"))

        form = {"username": "", "email": "", "role": "student"}
        if request.method == "POST":
            form["username"] = request.form.get("username", "").strip()
            form["email"] = request.form.get("email", "").strip().lower()
            form["role"] = request.form.get("role", "student")
            password = request.form.get("password", "")
            confirm = request.form.get("confirm_password", "")

            errors = []
            if not USERNAME_RE.match(form["username"]):
                errors.append(
                    "Username must be 3 to 30 characters: letters, numbers or underscores."
                )
            if not EMAIL_RE.match(form["email"]):
                errors.append("Enter a valid email address.")
            if len(password) < MIN_PASSWORD_LENGTH:
                errors.append(
                    f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
                )
            if password != confirm:
                errors.append("Passwords do not match.")
            if form["role"] not in SIGNUP_ROLES:
                errors.append("Choose either Student or Instructor.")

            if not errors:
                if db.session.scalar(
                    db.select(User).where(User.username == form["username"])
                ):
                    errors.append("That username is already taken.")
                if db.session.scalar(
                    db.select(User).where(User.email == form["email"])
                ):
                    errors.append("An account with that email already exists.")

            if errors:
                for message in errors:
                    flash(message, "error")
                return render_template("register.html", form=form), 400

            user = User(
                username=form["username"], email=form["email"], role=form["role"]
            )
            user.set_password(password)
            db.session.add(user)
            db.session.commit()

            flash("Account created. You can log in now.", "success")
            return redirect(url_for("login"))

        return render_template("register.html", form=form)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("dashboard"))

        identifier = ""
        if request.method == "POST":
            identifier = request.form.get("identifier", "").strip()
            password = request.form.get("password", "")

            # Accept either a username or an email address.
            user = db.session.scalar(
                db.select(User).where(
                    (User.username == identifier)
                    | (User.email == identifier.lower())
                )
            )

            # Same message for "no such user" and "wrong password", so the
            # form does not reveal which usernames exist.
            if user is None or not user.check_password(password):
                flash("Incorrect username/email or password.", "error")
                return render_template("login.html", identifier=identifier), 401
            if not user.is_active:
                flash("This account has been deactivated.", "error")
                return render_template("login.html", identifier=identifier), 403

            # Start a fresh session to avoid session fixation.
            session.clear()
            session["user_id"] = user.id
            flash(f"Welcome back, {user.username}!", "success")

            next_url = request.args.get("next")
            if is_safe_next(next_url):
                return redirect(next_url)
            return redirect(url_for("dashboard"))

        return render_template("login.html", identifier=identifier)

    # Logout is POST so a link or image on another site cannot log users out.
    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        session.clear()
        flash("You have been logged out.", "info")
        return redirect(url_for("login"))

    # --- Protected pages ----------------------------------------------------

    @app.route("/dashboard")
    @login_required
    def dashboard():
        # Each role has its own dashboard page.
        if g.user.is_student:
            return redirect(url_for("student_dashboard"))
        if g.user.is_instructor:
            return redirect(url_for("instructor_dashboard"))
        return redirect(url_for("admin_dashboard"))

    # --- Day 3: Course catalog ---------------------------------------------

    @app.template_filter("price")
    def format_price(value):
        return "Free" if not value else f"₹{value:,.0f}"

    @app.route("/courses")
    def course_list():
        filters = {
            "q": request.args.get("q", "").strip(),
            "category": request.args.get("category", ""),
            "level": request.args.get("level", ""),
            "price": request.args.get("price", ""),
        }

        # Only published courses are public. Featured ones come first.
        query = db.select(Course).where(Course.is_published.is_(True))
        if filters["q"]:
            like = f"%{filters['q']}%"
            query = query.where(
                Course.title.ilike(like)
                | Course.short_description.ilike(like)
                | Course.description.ilike(like)
            )
        if filters["category"] in CATEGORIES:
            query = query.where(Course.category == filters["category"])
        if filters["level"] in LEVELS:
            query = query.where(Course.level == filters["level"])
        if filters["price"] == "free":
            query = query.where(Course.price == 0)
        elif filters["price"] == "paid":
            query = query.where(Course.price > 0)
        query = query.order_by(Course.is_featured.desc(), Course.created_at.desc())

        page = db.paginate(query, per_page=9, error_out=False)
        return render_template(
            "course_list.html",
            page=page,
            filters=filters,
            categories=CATEGORIES,
            levels=LEVELS,
        )

    @app.route("/courses/<slug>")
    def course_detail(slug):
        course = db.first_or_404(db.select(Course).where(Course.slug == slug))
        # Drafts are visible only to their instructor and to admins.
        if not course.is_published:
            can_preview = g.user and (
                g.user.is_admin or g.user.id == course.instructor_id
            )
            if not can_preview:
                abort(404)

        enrollment = None
        if g.user and g.user.is_student:
            enrollment = get_enrollment(g.user.id, course.id)
        return render_template(
            "course_detail.html", course=course, enrollment=enrollment
        )

    @app.route("/search")
    def search():
        # The catalog page already handles search, so reuse it.
        return redirect(url_for("course_list", **request.args))

    # --- Day 4: Enrollment and learning ------------------------------------

    @app.route("/enroll/<int:course_id>", methods=["POST"])
    @student_required
    def enroll(course_id):
        course = db.get_or_404(Course, course_id)
        if not course.is_published:
            abort(404)

        if get_enrollment(g.user.id, course.id):
            flash("You're already enrolled in this course.", "info")
        else:
            # Payments are out of scope, so every course is free to join.
            db.session.add(Enrollment(student=g.user, course=course))
            db.session.commit()
            flash(f"You're enrolled in {course.title}. Happy learning!", "success")
        return redirect(url_for("course_player", slug=course.slug))

    @app.route("/student/dashboard")
    @student_required
    def student_dashboard():
        enrollments = sorted(
            g.user.enrollments, key=lambda e: e.enrolled_at, reverse=True
        )
        return render_template("student_dashboard.html", enrollments=enrollments)

    @app.route("/learn/<slug>")
    @student_required
    def course_player(slug):
        course = db.first_or_404(db.select(Course).where(Course.slug == slug))
        enrollment = get_enrollment(g.user.id, course.id)
        if enrollment is None:
            flash("Enroll in this course to start learning.", "warning")
            return redirect(url_for("course_detail", slug=course.slug))

        lessons = course.lessons
        done_ids = set(
            db.session.scalars(
                db.select(LessonCompletion.lesson_id)
                .join(Lesson)
                .where(
                    LessonCompletion.student_id == g.user.id,
                    Lesson.course_id == course.id,
                )
            )
        )

        # Open the lesson from ?lesson=<id>, else the first unfinished one.
        current = None
        wanted = request.args.get("lesson", type=int)
        if wanted:
            current = next((l for l in lessons if l.id == wanted), None)
        if current is None and lessons:
            current = next((l for l in lessons if l.id not in done_ids), lessons[0])

        prev_lesson = next_lesson = None
        if current:
            i = lessons.index(current)
            prev_lesson = lessons[i - 1] if i > 0 else None
            next_lesson = lessons[i + 1] if i + 1 < len(lessons) else None

        return render_template(
            "course_player.html",
            course=course,
            enrollment=enrollment,
            lesson=current,
            done_ids=done_ids,
            prev_lesson=prev_lesson,
            next_lesson=next_lesson,
        )

    @app.route("/lesson/<int:lesson_id>/complete", methods=["POST"])
    @student_required
    def toggle_completion(lesson_id):
        lesson = db.get_or_404(Lesson, lesson_id)
        course = lesson.course
        enrollment = get_enrollment(g.user.id, course.id)
        if enrollment is None:
            abort(403)

        done = db.session.scalar(
            db.select(LessonCompletion).where(
                LessonCompletion.student_id == g.user.id,
                LessonCompletion.lesson_id == lesson.id,
            )
        )
        if done:
            db.session.delete(done)
        else:
            db.session.add(LessonCompletion(student=g.user, lesson=lesson))
        db.session.flush()  # so progress below counts this change

        was_complete = enrollment.completed_at is not None
        enrollment.completed_at = utc_now() if enrollment.progress == 100 else None
        db.session.commit()
        if enrollment.completed_at and not was_complete:
            flash(f"You finished {course.title}. Well done!", "success")

        # After marking a lesson done, move on to the next one.
        go_to = lesson
        if not done:
            i = course.lessons.index(lesson)
            if i + 1 < len(course.lessons):
                go_to = course.lessons[i + 1]
        return redirect(url_for("course_player", slug=course.slug, lesson=go_to.id))

    # --- Day 5: Instructor course builder ---------------------------------

    def get_own_course(course_id):
        """A course the logged-in instructor owns, else 404 / 403."""
        if course_id is None:
            abort(404)
        course = db.get_or_404(Course, course_id)
        if course.instructor_id != g.user.id:
            abort(403)
        return course

    @app.route("/instructor/dashboard")
    @instructor_required
    def instructor_dashboard():
        courses = sorted(g.user.taught_courses, key=lambda c: c.created_at, reverse=True)
        return render_template("instructor_dashboard.html", courses=courses)

    @app.route("/instructor/course/new", methods=["GET", "POST"])
    @instructor_required
    def course_create():
        values = {"price": 0}
        if request.method == "POST":
            values, errors = read_course_form(request.form)
            if not errors:
                course = Course(slug=unique_slug(values["title"]), instructor=g.user, **values)
                db.session.add(course)
                db.session.commit()
                flash("Course saved as a draft. Now add some lessons.", "success")
                return redirect(url_for("lesson_list", course_id=course.id))
            for message in errors:
                flash(message, "error")
        return render_template(
            "course_builder.html", course=None, values=values,
            categories=CATEGORIES, levels=LEVELS,
        )

    @app.route("/instructor/course/<int:course_id>/edit", methods=["GET", "POST"])
    @instructor_required
    def course_edit(course_id):
        course = get_own_course(course_id)
        values = {
            "title": course.title,
            "short_description": course.short_description or "",
            "description": course.description or "",
            "category": course.category,
            "level": course.level,
            "price": course.price,
            "thumbnail": course.thumbnail or "",
        }
        if request.method == "POST":
            values, errors = read_course_form(request.form)
            if not errors:
                # The slug stays the same so existing links keep working.
                for field, value in values.items():
                    setattr(course, field, value)
                db.session.commit()
                flash("Course details updated.", "success")
                return redirect(url_for("lesson_list", course_id=course.id))
            for message in errors:
                flash(message, "error")
        return render_template(
            "course_builder.html", course=course, values=values,
            categories=CATEGORIES, levels=LEVELS,
        )

    @app.route("/instructor/course/<int:course_id>/lessons")
    @instructor_required
    def lesson_list(course_id):
        course = get_own_course(course_id)
        return render_template("lesson_manager.html", course=course)

    @app.route("/instructor/course/<int:course_id>/publish", methods=["POST"])
    @instructor_required
    def toggle_publish(course_id):
        course = get_own_course(course_id)
        if not course.is_published and not course.lessons:
            flash("Add at least one lesson before publishing.", "error")
        else:
            course.is_published = not course.is_published
            db.session.commit()
            if course.is_published:
                flash(f"{course.title} is live in the catalog.", "success")
            else:
                flash(f"{course.title} is now a draft.", "info")
        # The form sends back the page it was on, so we return there.
        next_url = request.form.get("next")
        if is_safe_next(next_url):
            return redirect(next_url)
        return redirect(url_for("lesson_list", course_id=course.id))

    @app.route("/instructor/lesson/new", methods=["GET", "POST"])
    @instructor_required
    def lesson_create():
        course = get_own_course(request.args.get("course_id", type=int))
        values = {"order": len(course.lessons) + 1}
        if request.method == "POST":
            values, errors = read_lesson_form(request.form)
            if not errors:
                if values["order"] is None:
                    values["order"] = len(course.lessons) + 1
                db.session.add(Lesson(course=course, **values))
                db.session.commit()
                flash("Lesson added.", "success")
                return redirect(url_for("lesson_list", course_id=course.id))
            for message in errors:
                flash(message, "error")
        return render_template("lesson_form.html", course=course, lesson=None, values=values)

    @app.route("/instructor/lesson/<int:lesson_id>/edit", methods=["GET", "POST"])
    @instructor_required
    def lesson_edit(lesson_id):
        lesson = db.get_or_404(Lesson, lesson_id)
        course = get_own_course(lesson.course_id)
        values = {
            "title": lesson.title,
            "content": lesson.content or "",
            "video_url": lesson.video_url or "",
            "duration": lesson.duration,
            "order": lesson.order,
            "is_free_preview": lesson.is_free_preview,
        }
        if request.method == "POST":
            values, errors = read_lesson_form(request.form)
            if not errors:
                if values["order"] is None:
                    values["order"] = lesson.order
                for field, value in values.items():
                    setattr(lesson, field, value)
                db.session.commit()
                flash("Lesson updated.", "success")
                return redirect(url_for("lesson_list", course_id=course.id))
            for message in errors:
                flash(message, "error")
        return render_template("lesson_form.html", course=course, lesson=lesson, values=values)

    @app.route("/instructor/lesson/<int:lesson_id>/delete", methods=["POST"])
    @instructor_required
    def lesson_delete(lesson_id):
        lesson = db.get_or_404(Lesson, lesson_id)
        course = get_own_course(lesson.course_id)
        db.session.delete(lesson)
        db.session.commit()
        flash(f"Deleted lesson: {lesson.title}", "info")
        return redirect(url_for("lesson_list", course_id=course.id))

    # --- Day 6: Admin panel -------------------------------------------------

    def count(query):
        return db.session.scalar(query) or 0

    @app.route("/admin")
    @admin_required
    def admin_dashboard():
        total_enrollments = count(db.select(db.func.count(Enrollment.id)))
        completed = count(
            db.select(db.func.count(Enrollment.id)).where(
                Enrollment.completed_at.is_not(None)
            )
        )
        stats = {
            "users": count(db.select(db.func.count(User.id))),
            "students": count(db.select(db.func.count(User.id)).where(User.role == "student")),
            "instructors": count(db.select(db.func.count(User.id)).where(User.role == "instructor")),
            "courses": count(db.select(db.func.count(Course.id))),
            "published": count(db.select(db.func.count(Course.id)).where(Course.is_published.is_(True))),
            "enrollments": total_enrollments,
            "completed": completed,
            "completion_rate": round(completed / total_enrollments * 100) if total_enrollments else 0,
        }

        # Top 5 courses by number of enrollments, for the bar chart.
        top_courses = db.session.execute(
            db.select(Course.title, db.func.count(Enrollment.id).label("students"))
            .join(Enrollment, Enrollment.course_id == Course.id)
            .group_by(Course.id)
            .order_by(db.desc("students"))
            .limit(5)
        ).all()

        recent = db.session.scalars(
            db.select(Enrollment).order_by(Enrollment.enrolled_at.desc()).limit(8)
        ).all()
        return render_template(
            "admin_dashboard.html", stats=stats, top_courses=top_courses, recent=recent
        )

    @app.route("/admin/users")
    @admin_required
    def admin_users():
        page = db.paginate(
            db.select(User).order_by(User.created_at.desc()), per_page=20, error_out=False
        )
        return render_template("admin_users.html", page=page, roles=ROLES)

    @app.route("/admin/user/<int:user_id>/role", methods=["POST"])
    @admin_required
    def toggle_user_role(user_id):
        user = db.get_or_404(User, user_id)
        role = request.form.get("role")
        if user.id == g.user.id:
            flash("You can't change your own role.", "error")
        elif role not in ROLES:
            flash("Unknown role.", "error")
        else:
            user.role = role
            db.session.commit()
            flash(f"{user.username} is now {'an' if role in ('admin', 'instructor') else 'a'} {role}.", "success")
        return redirect(url_for("admin_users", page=request.form.get("page", 1, type=int)))

    @app.route("/admin/user/<int:user_id>/active", methods=["POST"])
    @admin_required
    def toggle_user_active(user_id):
        user = db.get_or_404(User, user_id)
        if user.id == g.user.id:
            flash("You can't deactivate your own account.", "error")
        else:
            user.is_active = not user.is_active
            db.session.commit()
            state = "reactivated" if user.is_active else "deactivated"
            flash(f"{user.username} has been {state}.", "info")
        return redirect(url_for("admin_users", page=request.form.get("page", 1, type=int)))

    @app.route("/admin/courses")
    @admin_required
    def admin_courses():
        courses = db.session.scalars(
            db.select(Course).order_by(Course.created_at.desc())
        ).all()
        return render_template("admin_courses.html", courses=courses)

    @app.route("/admin/course/<int:course_id>/feature", methods=["POST"])
    @admin_required
    def toggle_featured(course_id):
        course = db.get_or_404(Course, course_id)
        course.is_featured = not course.is_featured
        db.session.commit()
        flash(f"{course.title} {'is now featured' if course.is_featured else 'is no longer featured'}.", "info")
        return redirect(url_for("admin_courses"))

    @app.route("/admin/course/<int:course_id>/publish", methods=["POST"])
    @admin_required
    def admin_toggle_publish(course_id):
        # Admins can take any course down (or put it back up) for moderation.
        course = db.get_or_404(Course, course_id)
        course.is_published = not course.is_published
        db.session.commit()
        flash(f"{course.title} is now {'published' if course.is_published else 'a draft'}.", "info")
        return redirect(url_for("admin_courses"))

    # --- Day 7: Profile ----------------------------------------------------

    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        user = g.user
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            bio = request.form.get("bio", "").strip()
            avatar = request.form.get("avatar", "").strip()

            errors = []
            if not EMAIL_RE.match(email):
                errors.append("Enter a valid email address.")
            elif email != user.email and db.session.scalar(
                db.select(User).where(User.email == email)
            ):
                errors.append("Another account already uses that email.")
            if len(bio) > 1000:
                errors.append("Bio must be 1000 characters or fewer.")
            if avatar and not is_web_url(avatar):
                errors.append("Avatar must be a link starting with http:// or https://.")

            if errors:
                for message in errors:
                    flash(message, "error")
            else:
                user.email, user.bio, user.avatar = email, bio, avatar or None
                db.session.commit()
                flash("Profile updated.", "success")
                return redirect(url_for("profile"))
        return render_template("profile.html", user=user)

    @app.route("/profile/password", methods=["POST"])
    @login_required
    def change_password():
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")

        if not g.user.check_password(current):
            flash("Your current password is incorrect.", "error")
        elif len(new) < MIN_PASSWORD_LENGTH:
            flash(f"New password must be at least {MIN_PASSWORD_LENGTH} characters.", "error")
        elif new != confirm:
            flash("New passwords do not match.", "error")
        else:
            g.user.set_password(new)
            db.session.commit()
            flash("Password changed.", "success")
        return redirect(url_for("profile"))

    # --- Errors -------------------------------------------------------------

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(error):
        # Undo any half-finished database work before showing the page.
        db.session.rollback()
        return render_template("errors/500.html"), 500

    # --- CLI ----------------------------------------------------------------

    @app.cli.command("create-admin")
    @click.option("--username", prompt=True)
    @click.option("--email", prompt=True)
    @click.password_option()
    def create_admin(username, email, password):
        """Create an admin account from the terminal."""
        email = email.strip().lower()
        exists = db.session.scalar(
            db.select(User).where((User.username == username) | (User.email == email))
        )
        if exists:
            raise click.ClickException("A user with that username or email exists.")
        admin = User(username=username, email=email, role="admin")
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
        click.echo(f"Admin '{username}' created.")

    @app.cli.command("seed")
    def seed():
        """Add demo users and courses so there is something to browse."""
        if db.session.scalar(db.select(Course)):
            click.echo("Database already has courses, skipping.")
            return

        def make_user(username, role):
            user = User(username=username, email=f"{username}@example.com", role=role)
            user.set_password("password123")
            db.session.add(user)
            return user

        make_user("admin", "admin")
        teacher = make_user("asha", "instructor")
        make_user("ravi", "student")

        demo = [
            ("Python for Beginners", "programming", "beginner", 0, True,
             "Write your first programs and learn how Python thinks.",
             ["Installing Python", "Variables and types", "If statements", "Loops", "Functions"]),
            ("Flask Web Development", "programming", "intermediate", 499, False,
             "Build and ship a real web app with Flask and SQLite.",
             ["Routes and views", "Templates with Jinja2", "Forms", "Databases with SQLAlchemy"]),
            ("UI Design Basics", "design", "beginner", 0, False,
             "Spacing, type and colour: the rules behind clean screens.",
             ["Visual hierarchy", "Typography", "Colour and contrast"]),
            ("Data Analysis with Pandas", "data", "intermediate", 799, False,
             "Clean, explore and chart real datasets with pandas.",
             ["DataFrames", "Cleaning data", "Grouping and joins", "Plotting"]),
            ("Starting a Small Business", "business", "advanced", 299, False,
             "From idea to first customer, step by step.",
             ["Finding an idea", "Pricing", "Your first sale"]),
        ]
        for title, category, level, price, featured, summary, lesson_titles in demo:
            course = Course(
                title=title,
                slug=slugify(title),
                short_description=summary,
                description=f"{summary}\n\nEach lesson is short and ends with a small exercise.",
                category=category,
                level=level,
                price=price,
                is_published=True,
                is_featured=featured,
                instructor=teacher,
            )
            course.lessons = [
                Lesson(
                    title=name,
                    order=i,
                    duration=10 + i * 5,
                    is_free_preview=(i == 1),
                    content=f"Notes for '{name}'.\n\nRead through, then try the exercise.",
                )
                for i, name in enumerate(lesson_titles, start=1)
            ]
            db.session.add(course)

        draft = Course(title="Advanced SQL (draft)", slug="advanced-sql-draft",
                       category="data", level="advanced", instructor=teacher)
        db.session.add(draft)
        db.session.commit()
        click.echo("Seeded 3 users (password: password123) and 6 courses.")

    @app.shell_context_processor
    def make_shell_context():
        return {
            "db": db,
            "User": User,
            "Course": Course,
            "Lesson": Lesson,
            "Enrollment": Enrollment,
            "LessonCompletion": LessonCompletion,
        }

    return app
