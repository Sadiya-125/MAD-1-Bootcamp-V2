import pytest

from app import create_app
from models import db


class TestConfig:
    TESTING = True
    SECRET_KEY = "test"
    SQLALCHEMY_DATABASE_URI = "sqlite://"  # in-memory, thrown away after each test
    WTF_CSRF_ENABLED = False  # tests post forms directly, without a token


@pytest.fixture
def app():
    app = create_app(TestConfig)
    # Same demo data as `flask seed`: admin, asha (instructor), ravi (student),
    # all with password "password123", plus 5 published courses and 1 draft.
    app.test_cli_runner().invoke(args=["seed"])
    yield app
    with app.app_context():
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def login(client):
    """Call login("ravi") inside a test to log in as that user."""

    def do_login(username, password="password123"):
        return client.post("/login", data={"identifier": username, "password": password})

    return do_login
